export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export interface FileData {
  id: string;
  name: string;
  content: string;
  language: string;
  updatedAt: any;
  ownerId: string;
  collaborators: string[];
  visibility: 'private' | 'public';
}

export interface PresenceData {
  userId: string;
  userName: string;
  userColor: string;
  cursor?: {
    lineNumber: number;
    column: number;
  };
  selection?: {
    startLineNumber: number;
    startColumn: number;
    endLineNumber: number;
    endColumn: number;
  };
  lastSeen: any;
}

export interface UserProfile {
  name: string;
  color: string;
}
