import { useEffect, useState } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db, auth, handleFirestoreError } from '../lib/firebase';
import { PresenceData, OperationType } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface PresenceBarProps {
  fileId: string;
}

export default function PresenceBar({ fileId }: PresenceBarProps) {
  const [users, setUsers] = useState<PresenceData[]>([]);

  useEffect(() => {
    if (!fileId || !auth.currentUser) return;

    const path = `files/${fileId}/presence`;
    const q = query(collection(db, 'files', fileId, 'presence'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const activeUsers: PresenceData[] = [];
      const now = Date.now();
      snapshot.forEach((doc) => {
        const data = doc.data() as any;
        const lastSeen = data.lastSeen?.toDate?.()?.getTime() || 0;
        if (now - lastSeen < 120000 || doc.id === auth.currentUser?.uid) {
          activeUsers.push({ userId: doc.id, ...data });
        }
      });
      setUsers(activeUsers);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return () => unsubscribe();
  }, [fileId]);

  return (
    <div className="flex -space-x-1.5 overflow-hidden items-center">
      <AnimatePresence>
        {users.map((user) => (
          <motion.div
            key={user.userId}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="inline-block h-6 w-6 rounded-full ring-1 ring-[#161b22] flex items-center justify-center text-[10px] font-bold text-white relative transition-transform hover:z-20 hover:scale-110 cursor-default"
            style={{ backgroundColor: user.userColor }}
            title={user.userName}
          >
            <img 
              src={`https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${user.userId}&backgroundColor=${user.userColor.replace('#', '')}`}
              alt={user.userName}
              className="h-full w-full rounded-full"
              referrerPolicy="no-referrer"
            />
            {user.userId === auth.currentUser?.uid && (
              <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-[#238636] border border-[#161b22] rounded-full" />
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
