import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, UserPlus, Shield, Globe, Lock, Mail, Trash2 } from 'lucide-react';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { FileData } from '../types';

interface ShareModalProps {
  file: FileData;
  onClose: () => void;
}

export default function ShareModal({ file, onClose }: ShareModalProps) {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAddCollaborator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || file.collaborators.includes(email.trim())) return;

    setLoading(true);
    try {
      const fileRef = doc(db, 'files', file.id);
      await updateDoc(fileRef, {
        collaborators: [...file.collaborators, email.trim().toLowerCase()],
        updatedAt: serverTimestamp()
      });
      setEmail('');
    } catch (err) {
      console.error('Error adding collaborator:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveCollaborator = async (targetEmail: string) => {
    try {
      const fileRef = doc(db, 'files', file.id);
      await updateDoc(fileRef, {
        collaborators: file.collaborators.filter(e => e !== targetEmail),
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.error('Error removing collaborator:', err);
    }
  };

  const toggleVisibility = async () => {
    try {
      const fileRef = doc(db, 'files', file.id);
      await updateDoc(fileRef, {
        visibility: file.visibility === 'public' ? 'private' : 'public',
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      console.error('Error toggling visibility:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl w-full max-w-md overflow-hidden"
      >
        <div className="flex items-center justify-between p-4 border-b border-[#30363d]">
          <div className="flex items-center gap-2">
            <UserPlus size={18} className="text-[#58a6ff]" />
            <h2 className="text-sm font-bold text-white">Share "{file.name}"</h2>
          </div>
          <button onClick={onClose} className="text-[#8b949e] hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Visibility Section */}
          <section className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-[#8b949e]">General Access</h3>
            <div className="flex items-center justify-between p-3 bg-[#0d1117] border border-[#30363d] rounded-md">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-[#1f242b]">
                  {file.visibility === 'public' ? <Globe size={18} className="text-[#3fb950]" /> : <Lock size={18} className="text-[#8b949e]" />}
                </div>
                <div>
                  <div className="text-sm font-medium text-[#c9d1d9] capitalize">{file.visibility}</div>
                  <div className="text-[10px] text-[#8b949e]">
                    {file.visibility === 'public' ? 'Anyone with the link can view' : 'Only collaborators can access'}
                  </div>
                </div>
              </div>
              <button 
                onClick={toggleVisibility}
                className="text-[10px] font-bold text-[#58a6ff] hover:underline"
              >
                Change
              </button>
            </div>
          </section>

          {/* Collaborators Section */}
          <section className="space-y-3">
            <h3 className="text-[11px] font-bold uppercase tracking-wider text-[#8b949e]">Collaborators</h3>
            
            <form onSubmit={handleAddCollaborator} className="flex gap-2">
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-[#8b949e]" size={14} />
                <input 
                  type="email"
                  placeholder="Add by email..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#0d1117] border border-[#30363d] rounded-md py-1.5 pl-9 pr-3 text-xs outline-none focus:border-[#58a6ff] transition-colors"
                />
              </div>
              <button 
                disabled={loading}
                className="px-3 py-1.5 bg-[#238636] hover:bg-[#2ea043] disabled:opacity-50 text-white text-xs font-bold rounded-md transition-colors"
              >
                Add
              </button>
            </form>

            <div className="space-y-2 max-h-40 overflow-y-auto pr-1 custom-scrollbar">
              {file.collaborators.length === 0 ? (
                <div className="text-center py-4 text-[10px] text-[#484f58] italic border border-dashed border-[#30363d] rounded">
                  No collaborators added yet
                </div>
              ) : (
                file.collaborators.map(cEmail => (
                  <div key={cEmail} className="flex items-center justify-between p-2 hover:bg-[#1f242b] rounded transition-colors group">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#58a6ff] to-[#bc8cff] flex items-center justify-center text-[10px] font-bold text-white uppercase">
                        {cEmail[0]}
                      </div>
                      <span className="text-xs text-[#c9d1d9]">{cEmail}</span>
                    </div>
                    <button 
                      onClick={() => handleRemoveCollaborator(cEmail)}
                      className="text-[#8b949e] hover:text-[#f85149] opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>

        <div className="p-4 bg-[#0d1117] border-t border-[#30363d] flex justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-[#21262d] border border-[#30363d] text-xs font-bold hover:bg-[#30363d] transition-colors"
          >
             Done
          </button>
        </div>
      </motion.div>
    </div>
  );
}
