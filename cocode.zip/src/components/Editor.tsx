import { useEffect, useRef, useState } from 'react';
import MonacoEditor, { OnMount } from '@monaco-editor/react';
import { doc, onSnapshot, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError } from '../lib/firebase';
import { OperationType, FileData } from '../types';

interface EditorProps {
  file: FileData;
  userProfile: { name: string; color: string };
}

export default function Editor({ file, userProfile }: EditorProps) {
  const [content, setContent] = useState(file.content);
  const editorRef = useRef<any>(null);
  const isRemoteChange = useRef(false);

  useEffect(() => {
    setContent(file.content);
  }, [file.id]);

  // Sync content from Firestore
  useEffect(() => {
    if (!file.id || !auth.currentUser) return;

    const path = `files/${file.id}`;
    const unsubscribe = onSnapshot(doc(db, 'files', file.id), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        if (data.content !== editorRef.current?.getValue()) {
          isRemoteChange.current = true;
          setContent(data.content);
          // Small race condition guard
          setTimeout(() => { if (isRemoteChange.current) isRemoteChange.current = false; }, 100);
        }
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    return () => unsubscribe();
  }, [file.id]);

  const handleEditorChange = (value: string | undefined) => {
    if (isRemoteChange.current) return;
    if (value === undefined) return;
    if (value === content) return;

    const path = `files/${file.id}`;
    const fileRef = doc(db, 'files', file.id);
    updateDoc(fileRef, {
      content: value,
      updatedAt: serverTimestamp()
    }).catch(err => {
      handleFirestoreError(err, OperationType.UPDATE, path);
    });
  };

  const syncLanguage = (filename: string) => {
    const ext = filename.split('.').pop() || '';
    const map: Record<string, string> = {
      'js': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'jsx': 'javascript',
      'py': 'python',
      'css': 'css',
      'html': 'html',
      'json': 'json',
      'md': 'markdown'
    };
    return map[ext] || 'plaintext';
  };

  const handleEditorDidMount: OnMount = (editor) => {
    editorRef.current = editor;

    editor.onDidChangeCursorPosition((e) => {
      if (!auth.currentUser) return;
      const path = `files/${file.id}/presence/${auth.currentUser.uid}`;
      const presenceRef = doc(db, 'files', file.id, 'presence', auth.currentUser.uid);
      updateDoc(presenceRef, {
        cursor: {
          lineNumber: e.position.lineNumber,
          column: e.position.column
        },
        lastSeen: serverTimestamp()
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, path));
    });

    editor.onDidChangeCursorSelection((e) => {
      if (!auth.currentUser) return;
      const path = `files/${file.id}/presence/${auth.currentUser.uid}`;
      const presenceRef = doc(db, 'files', file.id, 'presence', auth.currentUser.uid);
      updateDoc(presenceRef, {
        selection: {
          startLineNumber: e.selection.startLineNumber,
          startColumn: e.selection.startColumn,
          endLineNumber: e.selection.endLineNumber,
          endColumn: e.selection.endColumn
        },
        lastSeen: serverTimestamp()
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, path));
    });
  };

  return (
    <div className="w-full h-full bg-[#0d1117]">
      <MonacoEditor
        height="100%"
        language={syncLanguage(file.name)}
        theme="vs-dark"
        value={content}
        onChange={handleEditorChange}
        onMount={handleEditorDidMount}
        options={{
          fontSize: 13,
          fontFamily: 'JetBrains Mono',
          minimap: { enabled: true },
          scrollBeyondLastLine: false,
          wordWrap: 'on',
          automaticLayout: true,
          padding: { top: 12 },
          lineNumbersMinChars: 4,
          glyphMargin: false,
          folding: true,
        }}
      />
    </div>
  );
}
