import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal as TerminalIcon, X, ChevronRight, Minimize2, Maximize2 } from 'lucide-react';

export default function Terminal() {
  const [isOpen, setIsOpen] = useState(true);
  const [isMaximized, setIsMaximized] = useState(false);
  const [history, setHistory] = useState<string[]>([
    'Welcome to CoCode Terminal v1.0.0',
    'Type "help" for a list of commands.',
    ''
  ]);
  const [currentInput, setCurrentInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentInput.trim()) return;

    const cmd = currentInput.trim().toLowerCase();
    const newHistory = [...history, `> ${currentInput}`];

    switch (cmd) {
      case 'help':
        newHistory.push('Available commands: help, clear, ls, status, echo [text], build');
        break;
      case 'clear':
        setHistory([]);
        setCurrentInput('');
        return;
      case 'ls':
        newHistory.push('src/  package.json  README.md  public/');
        break;
      case 'status':
        newHistory.push('System: Operational');
        newHistory.push('Connection: Stabilized');
        newHistory.push('Latency: 14ms');
        break;
      case 'build':
        newHistory.push('Building project...');
        setTimeout(() => setHistory(prev => [...prev, '✔ Build successful (2.4s)']), 1000);
        break;
      default:
        if (cmd.startsWith('echo ')) {
          newHistory.push(currentInput.slice(5));
        } else {
          newHistory.push(`Command not found: ${cmd}`);
        }
    }

    setHistory(newHistory);
    setCurrentInput('');
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-[#238636] hover:bg-[#2ea043] text-white p-2.5 rounded-full shadow-lg transition-colors z-50 group"
      >
        <TerminalIcon size={18} />
        <span className="absolute right-full mr-2 px-2 py-1 bg-[#161b22] text-[10px] rounded border border-[#30363d] opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
          Open Terminal
        </span>
      </button>
    );
  }

  return (
    <motion.div 
      layout
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className={cn(
        "bg-[#0d1117] border-t border-[#30363d] flex flex-col font-mono text-xs",
        isMaximized ? "fixed inset-0 z-50" : "h-64"
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#161b22] border-b border-[#30363d]">
        <div className="flex items-center gap-2 text-[#8b949e]">
          <TerminalIcon size={14} />
          <span className="font-medium">Terminal - bash</span>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setIsMaximized(!isMaximized)}
            className="text-[#8b949e] hover:text-[#c9d1d9] transition-colors"
          >
            {isMaximized ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-[#8b949e] hover:text-[#f85149] transition-colors"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-1 text-[#c9d1d9]"
      >
        {history.map((line, i) => (
          <div key={i} className={line.startsWith('>') ? 'text-[#58a6ff]' : ''}>
            {line}
          </div>
        ))}
        <form onSubmit={handleCommand} className="flex items-center gap-1">
          <ChevronRight size={14} className="text-[#3fb950]" />
          <input 
            type="text"
            autoFocus
            value={currentInput}
            onChange={(e) => setCurrentInput(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-[#c9d1d9]"
          />
        </form>
      </div>
    </motion.div>
  );
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
