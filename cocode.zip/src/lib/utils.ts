import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateRandomUser() {
  const names = [
    'Pixel', 'Binary', 'Lambda', 'Syntax', 'Bracket', 'Node', 'Async', 'Buffer', 
    'Stack', 'Heap', 'Cursor', 'Pointer'
  ];
  const colors = [
    '#FF5733', '#33FF57', '#3357FF', '#F333FF', '#33FFF3', '#FFD433', 
    '#FF3385', '#0099FF', '#9933FF', '#FF9900', '#00CC99'
  ];
  
  return {
    name: `${names[Math.floor(Math.random() * names.length)]} ${Math.floor(Math.random() * 100)}`,
    color: colors[Math.floor(Math.random() * colors.length)]
  };
}
