/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useCallback } from 'react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  doc, 
  setDoc, 
  serverTimestamp, 
  query, 
  orderBy,
  getDoc,
  or,
  where
} from 'firebase/firestore';
import { signInAnonymously, onAuthStateChanged, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { db, auth, handleFirestoreError } from './lib/firebase';
import { FileData, UserProfile, OperationType } from './types';
import { generateRandomUser, cn } from './lib/utils';
import Editor from './components/Editor';
import PresenceBar from './components/PresenceBar';
import TerminalComponent from './components/Terminal';
import ShareModal from './components/ShareModal';
import { 
  FileCode, 
  Folder, 
  Search, 
  Github, 
  Settings, 
  Users, 
  Terminal as TerminalIcon, 
  Plus, 
  Code2,
  LogIn,
  MoreVertical,
  ChevronRight,
  Code,
  Share2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { nanoid } from 'nanoid';

export default function App() {
  const [files, setFiles] = useState<FileData[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authReady, setAuthReady] = useState(false);
  const [showTerminal, setShowTerminal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  const activeFile = files.find(f => f.id === activeFileId);

  const [authError, setAuthError] = useState<string | null>(null);

  // Initialize UI State
  useEffect(() => {
    // Generate/Load User Profile
    const savedProfile = localStorage.getItem('cocode_profile');
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile));
    } else {
      const newProfile = generateRandomUser();
      setUserProfile(newProfile);
      localStorage.setItem('cocode_profile', JSON.stringify(newProfile));
    }

    const unsub = onAuthStateChanged(auth, (user) => {
      if (!user) {
        signInAnonymously(auth).catch(err => {
          if (err.code === 'auth/admin-restricted-operation') {
            setAuthError("Auth providers (Anonymous/Google) must be enabled in Firebase Console.");
          }
          console.warn('Auth issue:', err.message);
          setLoading(false);
          setAuthReady(false); 
        });
      } else {
        setAuthError(null);
        setAuthReady(true);
        setLoading(false);
      }
    });

    return () => unsub();
  }, []);

  // Sync Files
  useEffect(() => {
    if (!authReady) return;

    const path = 'files';
    const q = query(
      collection(db, path),
      orderBy('updatedAt', 'desc')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedFiles: FileData[] = [];
      const userEmail = auth.currentUser?.email;
      const userId = auth.currentUser?.uid;

      snapshot.forEach((doc) => {
        const data = doc.data() as any;
        const isOwner = data.ownerId === userId;
        const isPublic = data.visibility === 'public';
        const isCollaborator = userEmail && data.collaborators?.includes(userEmail);

        if (isOwner || isPublic || isCollaborator) {
          fetchedFiles.push({ id: doc.id, ...data } as FileData);
        }
      });
      setFiles(fetchedFiles);
      
      if (fetchedFiles.length === 0 && auth.currentUser) {
        handleCreateWelcomeFile();
      }

      if (fetchedFiles.length > 0 && !activeFileId) {
        setActiveFileId(fetchedFiles[0].id);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return () => unsubscribe();
  }, [authReady]);

  const handleCreateWelcomeFile = async () => {
    if (!auth.currentUser) return;
    const welcomeFile: Omit<FileData, 'id'> = {
      name: 'Welcome.md',
      content: '# Welcome to CoCode! 🚀\n\nThis is a collaborative live coding editor.\n\n### Features:\n- **Real-time Sync**: Changes are synced instantly across all users.\n- **Presence**: See who else is coding in the top right.\n- **Access Control**: Share files with specific emails or make them public.\n- **Terminal**: Use the integrated terminal for mock builds.\n\nTry sharing this file using the button above!',
      language: 'markdown',
      ownerId: auth.currentUser.uid,
      updatedAt: serverTimestamp(),
      collaborators: [],
      visibility: 'public'
    };
    try {
      await addDoc(collection(db, 'files'), welcomeFile);
    } catch (e) {
      console.error("Error creating welcome file", e);
    }
  };

  // Presence Heartbeat
  useEffect(() => {
    if (!authReady || !activeFileId || !userProfile || !auth.currentUser) return;

    const updatePresence = () => {
      const presenceRef = doc(db, 'files', activeFileId, 'presence', auth.currentUser!.uid);
      setDoc(presenceRef, {
        userName: userProfile.name,
        userColor: userProfile.color,
        lastSeen: serverTimestamp()
      }, { merge: true }).catch(err => console.error('Presence error:', err));
    };

    updatePresence();
    const interval = setInterval(updatePresence, 30000); // Pulse every 30s as long as idle

    return () => clearInterval(interval);
  }, [activeFileId, authReady, userProfile]);

  const handleCreateFile = async () => {
    if (!auth.currentUser) return;
    
    const newFile: Omit<FileData, 'id'> = {
      name: `new-file-${nanoid(4)}.js`,
      content: '// Start coding here...',
      language: 'javascript',
      ownerId: auth.currentUser.uid,
      updatedAt: serverTimestamp(),
      collaborators: [],
      visibility: 'private'
    };

    const docRef = await addDoc(collection(db, 'files'), newFile);
    setActiveFileId(docRef.id);
  };

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  };

  if (loading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[#0d1117] text-[#c9d1d9] font-mono">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
        >
          <Code2 size={48} className="text-[#58a6ff]" />
        </motion.div>
        <div className="ml-6">
          <p className="text-sm font-bold tracking-widest uppercase opacity-50">CoCode System</p>
          <p className="text-xl">Initializing Workspace...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-[#0d1117] text-[#c9d1d9] font-sans select-none">
      {/* Auth Error Banner */}
      <AnimatePresence>
        {authError && (
          <motion.div 
            initial={{ height: 0 }} 
            animate={{ height: 'auto' }} 
            exit={{ height: 0 }}
            className="overflow-hidden bg-amber-900/20 border-b border-amber-500/30 px-4 py-1.5 flex items-center justify-center gap-2 text-[10px] text-amber-200"
          >
            <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
            <span>{authError}</span>
            <a 
              href="https://console.firebase.google.com" 
              target="_blank" 
              rel="noreferrer"
              className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/40 transition-colors underline decoration-dotted"
            >
              Open Console
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Navigation Bar */}
      <header className="flex h-10 w-full items-center justify-between border-b border-[#30363d] bg-[#161b22] px-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-[#58a6ff]">
            <Code2 size={20} />
            <span className="text-sm font-bold tracking-tight text-white">CoCode</span>
          </div>
          <div className="h-4 w-px bg-[#30363d]" />
          <nav className="flex items-center gap-4 text-[11px] font-medium text-[#8b949e]">
            <button className="hover:text-white transition-colors">File</button>
            <button className="hover:text-white transition-colors">Edit</button>
            <button className="hover:text-white transition-colors">Selection</button>
            <button className="hover:text-white transition-colors">View</button>
          </nav>
        </div>

        {/* Dynamic Center Title */}
        <div className="flex flex-1 items-center justify-center px-4">
          <div className="flex items-center gap-2 rounded border border-[#30363d] bg-[#0d1117] px-3 py-1 text-[11px] text-[#8b949e] max-w-sm">
            <Folder size={12} />
            <span className="truncate">{activeFile?.name || 'Workspace'}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {activeFileId && <PresenceBar fileId={activeFileId} />}
          <div className="h-4 w-px bg-[#30363d]" />
          {(!auth.currentUser || auth.currentUser.isAnonymous) ? (
            <button 
              onClick={handleLogin}
              className="flex items-center gap-2 rounded bg-[#21262d] border border-[#30363d] px-3 py-1 text-[11px] font-bold text-white hover:bg-[#30363d] transition-colors"
            >
              <LogIn size={12} className="text-[#58a6ff]" />
              Sign in for Sharing
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowShareModal(true)}
                disabled={activeFile?.ownerId !== auth.currentUser.uid}
                className="flex items-center gap-2 rounded bg-[#238636] px-3 py-1 text-[11px] font-bold text-white hover:bg-[#2ea043] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Share2 size={12} />
                Share
              </button>
              <div className="flex items-center gap-2 px-2 bg-[#21262d] rounded py-1 border border-[#30363d]">
                <div className="h-1.5 w-1.5 rounded-full bg-[#238636]" />
                <span className="text-[10px] font-mono opacity-80">{auth.currentUser?.email?.split('@')[0]}</span>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex flex-1 overflow-hidden">
        {/* Activity Bar */}
        <aside className="flex w-12 flex-col items-center border-r border-[#30363d] bg-[#161b22] py-4 gap-6">
          <button className="text-white opacity-100"><FileCode size={22} /></button>
          <button className="text-[#8b949e] hover:text-white"><Search size={22} /></button>
          <button className="text-[#8b949e] hover:text-white"><Github size={22} /></button>
          <button 
            onClick={() => setShowTerminal(!showTerminal)}
            className={cn("hover:text-white transition-colors", showTerminal ? "text-white" : "text-[#8b949e]")}
          >
            <TerminalIcon size={22} />
          </button>
          <button className="text-[#8b949e] hover:text-white mt-auto mb-2"><Settings size={22} /></button>
        </aside>

        {/* Side Bar (Explorer) */}
        <aside className="flex w-56 flex-col border-r border-[#30363d] bg-[#0d1117]">
          <div className="flex h-9 items-center justify-between px-4 text-[11px] font-bold uppercase tracking-wider opacity-60">
            Explorer
            <button 
              onClick={handleCreateFile}
              className="hover:text-white transition-colors"
            >
              <Plus size={14} />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            <div className="flex items-center px-2 py-1 text-[11px] font-bold text-[#c9d1d9] bg-[#1f242b] border-y border-[#30363d] cursor-default">
              <ChevronRight size={14} className="mr-1 text-[#8b949e]" />
              <span className="uppercase tracking-tight">Source</span>
            </div>
            <div className="mt-1">
              <AnimatePresence>
                {files.map((file) => (
                  <motion.div
                    key={file.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    onClick={() => setActiveFileId(file.id)}
                    className={cn(
                      "flex items-center px-4 py-1.5 text-xs cursor-pointer group transition-colors",
                      activeFileId === file.id ? "bg-[#1f242b] text-white border-l-2 border-[#58a6ff]" : "text-[#8b949e] hover:bg-[#161b22] hover:text-[#c9d1d9]"
                    )}
                  >
                    <Code size={14} className={cn("mr-2", activeFileId === file.id ? "text-[#58a6ff]" : "text-[#484f58]")} />
                    <span className="flex-1 truncate font-mono">{file.name}</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Collaborators section in sidebar */}
          <div className="h-48 border-t border-[#30363d] overflow-hidden flex flex-col bg-[#0d1117]">
            <div className="px-4 py-3 text-[11px] uppercase tracking-wider font-bold opacity-60 border-b border-[#30363d]/50 bg-[#161b22]/30 flex items-center justify-between">
              Collaborators
              <Users size={12} />
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {activeFile?.collaborators.length ? (
                activeFile.collaborators.map(email => (
                  <div key={email} className="flex items-center gap-2 text-xs group">
                    <div className="h-2 w-2 rounded-full bg-[#58a6ff]"></div>
                    <span className="truncate opacity-80">{email}</span>
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center h-full opacity-30 text-center gap-1">
                  <span className="text-[10px] italic">Only you have access</span>
                </div>
              )}
            </div>
          </div>
        </aside>

        {/* Editor Area */}
        <section className="flex flex-1 flex-col overflow-hidden bg-[#0d1117] relative">
          {/* Tabs */}
          <div className="flex h-9 border-b border-[#30363d] bg-[#161b22]">
            {activeFile && (
               <div className="flex items-center bg-[#0d1117] px-4 border-t border-[#58a6ff] border-x border-[#30363d] text-xs h-full">
                  <span className="text-[#c9d1d9] font-mono">{activeFile.name}</span>
                  <button className="ml-3 text-[#8b949e] hover:text-white">×</button>
               </div>
            )}
          </div>

          <div className="flex-1 overflow-hidden flex flex-col relative">
            {activeFile ? (
              <>
                <Editor file={activeFile} userProfile={userProfile!} />
                <AnimatePresence>
                  {showTerminal && (
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: 'auto' }}
                      exit={{ height: 0 }}
                      className="overflow-hidden"
                    >
                      <TerminalComponent />
                    </motion.div>
                  )}
                </AnimatePresence>
              </>
            ) : (
              <div className="flex h-full flex-col items-center justify-center text-[#484f58] gap-4">
                <Code2 size={64} strokeWidth={1} className="opacity-20" />
                <p className="text-sm font-bold tracking-widest uppercase opacity-40">Ready to code</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <AnimatePresence>
        {showShareModal && activeFile && (
          <ShareModal 
            file={activeFile} 
            onClose={() => setShowShareModal(false)} 
          />
        )}
      </AnimatePresence>

      {/* Status Bar */}
      <footer className="flex h-6 w-full items-center justify-between border-t border-[#30363d] bg-[#161b22] px-3 text-[10px] text-[#8b949e] font-medium">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 hover:text-white cursor-pointer px-1">
             <Code2 size={12} className="text-[#58a6ff]" />
             <span>Main Branch</span>
          </div>
          <div className="flex items-center gap-1 hover:text-white cursor-pointer px-1">
             <div className="h-2 w-2 rounded-full bg-[#238636]" />
             <span>Collaborative Session</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="hover:text-white cursor-pointer">Spaces: 2</span>
          <span className="hover:text-white cursor-pointer font-bold text-[#58a6ff]">{activeFile?.language?.toUpperCase() || 'PLAIN TEXT'}</span>
          <span className="hover:text-white cursor-pointer">UTF-8</span>
        </div>
      </footer>
    </div>
  );
}
